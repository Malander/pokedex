import '../scss/main.scss';
import { App } from './App';

void App.init();
